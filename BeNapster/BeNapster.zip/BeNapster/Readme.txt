BeNapster

BeNapster is a beginnings of a GPL'ed Napster client for BeOS.

Napster, for those who have no idea what I' m on about, is a new way of sharing those nice legal mp3's you have on your hard drive using a client server model.

Its only Alpha quality at the moment, a number of things that you could reasonable expect to happen, like failing connection have not been accounted for and will make BeNapster crash. It is far from feature complete but will allow you to search and download mp3's which is what most people want to do. It does not yet allow you to resume downloads that have been aborted. It does not allow others to download your files and you can not chat using Napsters chat system.

At the moment the code and the enclosed binary is for Intel only, PPC owners are more than welcome to submit source code changes to make it a cross platform program. Please note however that this software and source code is protected by the GNU Public Licence...

BeNapster - Napster Client for the Be Operating system
Copyright(C) 2000 David Burnett
vargol@bigfoot.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



